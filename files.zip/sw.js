// ══════════════════════════════════════════════════════
// 📱 SERVICE WORKER — Lectura en Familia 2026
// Modo offline completo para estudiantes sin internet
// ══════════════════════════════════════════════════════

const CACHE_NAME = 'lectura-familia-v2';

const CACHE_URLS = [
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(CACHE_URLS).catch(err => {
        console.log('SW: algunos archivos no cacheados:', err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if(event.request.method !== 'GET') return;
  const url = event.request.url;

  // Firebase y Groq — siempre red, sin cache
  if(url.includes('firebaseio.com') || url.includes('firebasestorage') ||
     url.includes('groq.com') || url.includes('googleapis.com/v0/b')){
    event.respondWith(
      fetch(event.request).catch(() =>
        new Response(JSON.stringify({offline:true}), {headers:{'Content-Type':'application/json'}})
      )
    );
    return;
  }

  // Fonts — cache primero
  if(url.includes('fonts.googleapis.com') || url.includes('fonts.gstatic.com')){
    event.respondWith(
      caches.match(event.request).then(cached => cached ||
        fetch(event.request).then(res => {
          const clone = res.clone();
          caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
          return res;
        })
      )
    );
    return;
  }

  // App — cache inmediato + actualizar en background
  event.respondWith(
    caches.match(event.request).then(cached => {
      const net = fetch(event.request).then(res => {
        if(res && res.status === 200){
          const clone = res.clone();
          caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
        }
        return res;
      }).catch(() => null);
      return cached || net || caches.match('./index.html');
    })
  );
});
